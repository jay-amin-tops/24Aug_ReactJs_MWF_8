import React from 'react';
import { Routes,Route } from 'react-router-dom';
import IntroFunctionalCompo from './01IntroFunctionalCompo.jsx';
// import ExampleCompo from './component/02ExampleCompo.jsx';
const FunctionalCompoRouter = () => {
    // console.log("called");
    return (
        <>
            <Routes>
                <Route index element={<IntroFunctionalCompo />} />
                {/* <Route path="/" element={<IntroFunctionalCompo />} ></Route> */}
            </Routes>
        </>
    );
};

export default FunctionalCompoRouter;