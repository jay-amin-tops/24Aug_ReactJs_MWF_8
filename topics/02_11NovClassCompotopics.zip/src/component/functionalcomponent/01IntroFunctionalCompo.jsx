import React from 'react';

const IntroFunctionalCompo = () => {
    return (
        <div>
            <div className="row">
                <div className="col-md-4 offset-md-8">
                    IntroFunctionalCompo
                </div>
            </div>
        </div>
    );
};

export default IntroFunctionalCompo;