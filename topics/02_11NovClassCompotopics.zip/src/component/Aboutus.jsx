import React from 'react';

const Aboutus = () => {
    return (
        <div>
            Aboutus page data
        </div>
    );
};

export default Aboutus;