import React from 'react';

const Contact = () => {
    return (
        <div>
            Contact Us Page
        </div>
    );
};

export default Contact;