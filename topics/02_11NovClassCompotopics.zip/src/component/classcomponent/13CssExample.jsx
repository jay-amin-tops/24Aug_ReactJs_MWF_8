import React, { Component } from 'react';
import styledComponents from 'styled-components';
import "./custom.css";
class CssExample extends Component {
    render() {
        const custCSS = {
            color: "blue",
            backgroundColor: "orange"
        }
        const Wrapper = styledComponents.section`
                        padding: 4em;
                        background: papayawhip;
                        `;
        const Btn = styledComponents.button`
                        color: green;
                        font-size: 1em;
                        margin: 1em;
                        padding: 0.25em 1em;
                        border: 2px solid palevioletred;
                        border-radius: 3px;
                        `;
        const txtc = {
            color: "blue",
            background: "yellow"
        };
        const txts = {
            fontSize: "80px"
        };
        return (
            <>
                <p style={custCSS}>test</p>
                <p style={{ color: "blue", backgroundColor: "orange" }}>test</p>
                <h2>Something</h2>
                <Btn>test</Btn>
                <Wrapper>data</Wrapper>
                <h1 style={{ ...txtc, ...txts }}>Hello App</h1>
            </>
        );
    }
}


export default CssExample;